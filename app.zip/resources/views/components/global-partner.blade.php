<section id="brand-partners" class="brand-partners">
        <div class="container">
            <h2 class="section-title">Our Global Partners</h2>
            <div class="brand-marquee">
                <div class="brand-track">
                    <div class="brand-slide">
                        <img src="assets/universities/Oxford-University.png" alt="Oxford University">
                    </div>
                    <div class="brand-slide">
                        <img src="assets/universities/Harvard-Logo.png" alt="Harvard University">
                    </div>
                    <div class="brand-slide">
                        <img src="assets/universities/MIT_logo.png" alt="MIT">
                    </div>
                    <div class="brand-slide">
                        <img src="assets/universities/Stanford_University_Logo.png" alt="Stanford University">
                    </div>
                    <div class="brand-slide">
                        <img src="assets/universities/cambridge-logo.png" alt="Cambridge University">
                    </div>
                    <div class="brand-slide">
                        <img src="assets/universities/Berkeley-logo.png" alt="UC Berkeley">
                    </div>
                    <div class="brand-slide">
                        <img src="assets/universities/Oxford-University.png" alt="Oxford University">
                    </div>
                    <div class="brand-slide">
                        <img src="assets/universities/Harvard-Logo.png" alt="Harvard University">
                    </div>
                    <div class="brand-slide">
                        <img src="assets/universities/MIT_logo.png" alt="MIT">
                    </div>
                    <div class="brand-slide">
                        <img src="assets/universities/Stanford_University_Logo.png" alt="Stanford University">
                    </div>
                    <div class="brand-slide">
                        <img src="assets/universities/cambridge-logo.png" alt="Cambridge University">
                    </div>
                    <div class="brand-slide">
                        <img src="assets/universities/Berkeley-logo.png" alt="UC Berkeley">
                    </div>
                </div>
            </div>
        </div>

    </section>