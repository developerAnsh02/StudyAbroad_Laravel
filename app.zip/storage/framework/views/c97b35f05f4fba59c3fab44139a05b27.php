<header class="header">
    <div class="container">
        <div class="hamburger-menu">
            <div class="hamburger-icon" onclick="toggleMenu()">☰</div>
            <div class="hamburger-overlay">
                <nav class="hamburger-nav">
                    <a href="<?php echo e(url('/')); ?>">Home</a>
                    <a href="<?php echo e(url('/services')); ?>">Programs</a>
                    <a href="#scholarships">Scholarships</a>
                    <a href="<?php echo e(url('/about')); ?>">About Us</a>
                    <a href="<?php echo e(url('/contact')); ?>">Contact Us</a>
                </nav>
            </div>
        </div>

        <div class="navbar-container">
            <div class="navbar">
                <div class="logo">
                    <a href="<?php echo e(url('/')); ?>">StudyAbroad<span>.com</span></a>
                </div>
                <nav class="nav-links">
                    <a class="nav-item" href="<?php echo e(url('/')); ?>">Home</a>
                    <a class="nav-item" href="#programs">Programs</a>
                    <a class="nav-item" href="#scholarships">Scholarships</a>
                    <a class="nav-item" href="<?php echo e(url('/about')); ?>">About Us</a>
                    <a href="<?php echo e(url('/contact')); ?>" class="contact-btn">Contact Us</a>
                </nav>
            </div>
        </div>
    </div>
</header>
<?php /**PATH /Users/amanmehta/Desktop/web_d/StudyAbroad_Laravel/resources/views/layouts/navigation.blade.php ENDPATH**/ ?>