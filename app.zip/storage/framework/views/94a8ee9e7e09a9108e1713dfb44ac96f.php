<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>">
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('assets/image-removebg-preview (4).png')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="<?php echo e(asset('script.js')); ?>" defer></script>
    <title><?php echo $__env->yieldContent('title', 'Study Abroad'); ?></title>
</head>
<body>
    <div class="whatsapp-container">
        <a href="https://api.whatsapp.com/send?phone=YOUR_PHONE_NUMBER" target="_blank" class="whatsapp-icon">
            <img src="<?php echo e(asset('icons/WhatsApp_icon.png')); ?>" alt="WhatsApp" />
            <div class="tooltip">Chat with us on WhatsApp!</div>
        </a>
    </div>
    <?php echo $__env->make('layouts.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> <!-- Navigation Bar -->
    <main>
        <?php echo $__env->yieldContent('content'); ?> <!-- Page Content -->
    </main>
    <?php echo $__env->make('layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> <!-- Footer -->
    <button id="backToTop" class="back-to-top">↑</button>
</body>
</html>
 <footer class="footer"></footer><?php /**PATH C:\xampp\htdocs\laravel\StudyAbroad_Laravel\StudyAbroad_Laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>