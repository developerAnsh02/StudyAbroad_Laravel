<?php $__env->startSection('content'); ?>

<section class="hero">
                <div class="hero-overlay"></div>
                <div class="hero-content-wrapper">
                    <!-- Hero Content -->
                    <div class="hero-content">
                        <div class="plane-container">
                            <img src="assets/plane.png" alt="Aeroplane" class="plane">
                        </div>
                        
                        <h1>Your Gateway to Hassle-Free Travel</h1>
                        <p>Get expert visa assistance and make your travel dreams a reality.</p>
                        <div class="cta-buttons">
                            <a href="#services" class="btn">Learn More</a>
                            <a href="contact.html" class="btn-secondary">Contact Us</a>
                        </div>
                        
                    </div>
                    <!-- Registration Form -->
                    <div class="registration-form">
                        <h2>Register for Visa Assistance</h2>
                        <form id="registrationForm">
                            <div class="form-group">
                                <input type="text" id="name" name="name" required placeholder="Your Name">
                            </div>
                            <div class="form-group">
                                <input type="tel" id="phone" name="phone" required placeholder="Phone Number">
                            </div>
                            <div class="form-group">
                                <input type="email" id="email" name="email" required placeholder="Email">
                            </div>
                            <div class="form-group">
                                <input type="text" id="country" name="country" required placeholder="Your Country">
                            </div>
                            <div class="form-group">
                                <input type="text" id="visa-country" name="visa_country" required
                                    placeholder="Visa Required Country">
                            </div>
                            <div class="form-group">
                                <select id="visa-type" name="visa_type" required>
                                    <option value="" disabled selected>Select Visa Type</option>
                                    <option value="Tourist Visa">Tourist Visa</option>
                                    <option value="Work Visa">Work Visa</option>
                                    <option value="Student Visa">Student Visa</option>
                                    <option value="Business Visa">Business Visa</option>
                                </select>
                            </div>
                            <button type="submit" class="submit-btn">Submit</button>
                        </form>
                    </div>
                </div>
                <div class="globe-container">
                    <img src="/assets/PinClipart.com_travel-clipart_290936.png" alt="Globe" class="globe">
                </div>
            </section>
    <section class="visa-services" id="visa-services">
        <div class="container">
            <h2 class="section-title">Our Visa Services</h2>
            <div class="visa-service-cards">
                <!-- Tourist Visa -->
                <div class="visa-service-card">
                    <img src="icons/icons8-tourist-pulsar-color/icons8-tourist-96.png" alt="Tourist Visa">
                    <div class="service-content">
                        <h3>Tourist Visa</h3>
                        <p>Explore the world with ease! Our tourist visa services ensure a smooth and stress-free
                            application process.</p>
                        <a href="#" class="learn-more">Learn More →</a>
                    </div>
                </div>

                <!-- Travel Visa -->
                <div class="visa-service-card">
                    <img src="icons/icons8-tour-pulsar-color/icons8-tour-96.png" alt="Travel Visa">
                    <div class="service-content">
                        <h3>Travel Visa</h3>
                        <p>Travel without worries! Get professional guidance for quick and accurate travel visa
                            approvals.</p>
                        <a href="#" class="learn-more">Learn More →</a>
                    </div>
                </div>

                <!-- Transit Visa -->
                <div class="visa-service-card">
                    <img src="icons/icons8-in-transit-pulsar-color/icons8-in-transit-96.png" alt="Transit Visa">
                    <div class="service-content">
                        <h3>Transit Visa</h3>
                        <p>Need a stopover visa? Our experts will handle the details to ensure a smooth transition
                            between flights.</p>
                        <a href="#" class="learn-more">Learn More →</a>
                    </div>
                </div>
            </div>
        </div>
    </section>



    <section id="services" class="services">
        <div class="container">
            <h2 class="section-title">Our Services</h2>
            <p class="section-description">Explore the wide range of services we offer to help you achieve your study
                abroad dreams.</p>
            <div class="services-grid">
                <!-- Service 1 -->
                <div class="service-card">
                    <img src="icons/icons8-program-pulsar-color/icons8-program-96.png" alt="Programs">
                    <h3>Study Programs</h3>
                    <p>Explore a wide range of programs across top universities worldwide.</p>
                </div>
                <!-- Service 2 -->
                <div class="service-card">
                    <img src="icons/icons8-consultation-pulsar-color/icons8-consultation-96.png" alt="Consultation">
                    <h3>Free Consultation</h3>
                    <p>Get expert guidance on choosing the right university and course.</p>
                </div>
                <!-- Service 3 -->
                <div class="service-card">
                    <img src="icons/icons8-application-pulsar-color/icons8-application-96.png" alt="Application">
                    <h3>Application Assistance</h3>
                    <p>Help with documentation, SOP, LOR, and application submissions.</p>
                </div>
                <!-- Service 4 -->
                <div class="service-card">
                    <img src="icons/icons8-passport-and-tickets-pulsar-color/icons8-passport-and-tickets-96.png"
                        alt="Visa">
                    <h3>Visa Guidance</h3>
                    <p>Complete visa assistance, including interview preparation.</p>
                </div>
                <!-- Service 5 -->
                <div class="service-card">
                    <img src="icons/icons8-country-house-pulsar-color/icons8-country-house-96.png" alt="Accommodation">
                    <h3>Accommodation Support</h3>
                    <p>Find the best on-campus and off-campus housing options.</p>
                </div>
                <!-- Service 6 -->
                <div class="service-card">
                    <img src="icons/icons8-valet-pulsar-color/icons8-valet-96.png" alt="Job">
                    <h3>Internship & Job Support</h3>
                    <p>Guidance on finding part-time jobs and internship opportunities.</p>
                </div>
            </div>
        </div>
    </section>

    <section id="brand-partners" class="brand-partners">
        <div class="container">
            <h2 class="section-title">Our Global Partners</h2>
            <div class="brand-marquee">
                <div class="brand-track">
                    <div class="brand-slide">
                        <img src="assets/universities/Oxford-University.png" alt="Oxford University">
                    </div>
                    <div class="brand-slide">
                        <img src="assets/universities/Harvard-Logo.png" alt="Harvard University">
                    </div>
                    <div class="brand-slide">
                        <img src="assets/universities/MIT_logo.png" alt="MIT">
                    </div>
                    <div class="brand-slide">
                        <img src="assets/universities/Stanford_University_Logo.png" alt="Stanford University">
                    </div>
                    <div class="brand-slide">
                        <img src="assets/universities/cambridge-logo.png" alt="Cambridge University">
                    </div>
                    <div class="brand-slide">
                        <img src="assets/universities/Berkeley-logo.png" alt="UC Berkeley">
                    </div>
                    <div class="brand-slide">
                        <img src="assets/universities/Oxford-University.png" alt="Oxford University">
                    </div>
                    <div class="brand-slide">
                        <img src="assets/universities/Harvard-Logo.png" alt="Harvard University">
                    </div>
                    <div class="brand-slide">
                        <img src="assets/universities/MIT_logo.png" alt="MIT">
                    </div>
                    <div class="brand-slide">
                        <img src="assets/universities/Stanford_University_Logo.png" alt="Stanford University">
                    </div>
                    <div class="brand-slide">
                        <img src="assets/universities/cambridge-logo.png" alt="Cambridge University">
                    </div>
                    <div class="brand-slide">
                        <img src="assets/universities/Berkeley-logo.png" alt="UC Berkeley">
                    </div>
                </div>
            </div>
        </div>
        
    </section>

    <section id="testimonials" class="testimonials">
        <div class="container">
            <h2 class="section-title">What Our Students Say</h2>
            <div class="testimonial-slider">
                <div class="testimonial-track">
                    <!-- Testimonial 1 -->
                    <div class="testimonial-card">
                        <span class="quote open">“</span>
                        <p class="testimonial-text">
                            "Thanks to StudyAbroad.com, I got admission to my dream university! The process was smooth and well-guided."
                        </p>
                        <div class="testimonial-author">
                            <div class="image">
                                <img src="students/student1.jpg" alt="John Doe">
                            </div>
                            <div class="author-info">
                                <h4>John Doe</h4>
                                <span>Harvard University</span>
                            </div>
                        </div>
                        <span class="quote close">”</span>
                    </div>
    
                    <!-- Testimonial 2 -->
                    <div class="testimonial-card">
                        <span class="quote open">“</span>
                        <p class="testimonial-text">
                            "The visa assistance and application guidance were exceptional. Highly recommend their services!"
                        </p>
                        <div class="testimonial-author">
                            <div class="image">
                                <img src="students/student2.jpg" alt="Jane Smith">
                            </div>
                            <div class="author-info">
                                <h4>Jane Smith</h4>
                                <span>Oxford University</span>
                            </div>
                        </div>
                        <span class="quote close">”</span>
                    </div>
    
                    <!-- Testimonial 3 -->
                    <div class="testimonial-card">
                        <span class="quote open">“</span>
                        <p class="testimonial-text">
                            "The team helped me with scholarships and accommodation. Truly life-changing experience!"
                        </p>
                        <div class="testimonial-author">
                            <div class="image">
                                <img src="students/student3.jpg" alt="Emily Johnson">
                            </div>
                            <div class="author-info">
                                <h4>Emily Johnson</h4>
                                <span>MIT</span>
                            </div>
                        </div>
                        <span class="quote close">”</span>
                    </div>
                </div>
            </div>
    
            <!-- Navigation Buttons -->
            <button class="prev-btn" onclick="prevSlide()">&#10094;</button>
            <button class="next-btn" onclick="nextSlide()">&#10095;</button>
    
            <!-- Dot Indicators -->
            <div class="dots">
                <span class="dot active" onclick="goToSlide(0)"></span>
                <span class="dot" onclick="goToSlide(1)"></span>
                <span class="dot" onclick="goToSlide(2)"></span>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/amanmehta/Desktop/web_d/StudyAbroad_Laravel/resources/views/home.blade.php ENDPATH**/ ?>