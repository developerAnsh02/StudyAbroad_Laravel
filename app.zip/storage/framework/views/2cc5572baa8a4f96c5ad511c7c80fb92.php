<section class="hero">
    <div class="hero-overlay"></div>
    <div class="hero-content-wrapper">
        <div class="hero-content">
            <h1>Make Your Study Abroad Dreams Come True - Hassle-Free!</h1>
            <p>Study abroad is a life altering experience but the process is complicated. That's where we step in. At WTS study visa consultants we walk you through each step – from selecting the best destination to getting your visa and settling down. Our experts facilitate a hassle-free stress-free experience, assist you in selecting the top universities and scholarships that suit your aspirations. With years of experience and in-depth knowledge of international education systems, we ease your transition and make it a success. Begin your study abroad experience with confidence – we'll assist you in turning your dream into reality.</p>
            <div class="cta-buttons">
                <a href="#services" class="btn">Learn More</a>
                <a href="contact.html" class="btn-secondary">Contact Us</a>
            </div>
        </div>
    </div>
</section>

<style>
.hero {
    position: relative;
    width: 100%;
    height: 100vh;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    padding: 40px 20px; /* Adjust for spacing from top and bottom */
    background: url('/assets/herobg.jpg') no-repeat center center/cover;
    box-sizing: border-box;
}

.hero-content-wrapper {
    margin-top: 70px;
    position: relative;
    z-index: 1;
    text-align: center;
    color: #ffffff;
}

.hero-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(46, 46, 46, 0.22);
    backdrop-filter: blur(10px);
}

.cta-buttons {
    margin-top: 20px;
    display: flex;
    gap: 15px;
    justify-content: center;
}

.btn, .btn-secondary {
    padding: 10px 20px;
    border-radius: 8px;
    text-decoration: none;
}

.btn {
    background-color: #1a73e8;
    color: #ffffff;
}

.btn-secondary {
    background-color: #ffffff;
    color: #1a73e8;
}

</style><?php /**PATH C:\xampp\htdocs\laravel\StudyAbroad_Laravel\StudyAbroad_Laravel\resources\views/components/hero-new.blade.php ENDPATH**/ ?>