<section class="hero">
        <div class="hero-overlay"></div>
        <div class="hero-content-wrapper">
            <div class="hero-content">
                <div class="plane-container">
                    <img src="assets/plane.png" alt="Aeroplane" class="plane">
                </div>

                <h1>Make Your Study Abroad Dreams Come True – Hassle-Free!</h1>
                <p>Get expert visa assistance and make your travel dreams a reality.</p>
                <div class="cta-buttons">
                    <a href="#services" class="btn">Learn More</a>
                    <a href="contact.html" class="btn-secondary">Contact Us</a>
                </div>

            </div>
            <!-- Registration Form -->
            <div class="registration-form">
                <h2>Register for Visa Assistance</h2>
                <form id="registrationForm">
                    <div class="form-group">
                        <input type="text" id="name" name="name" required placeholder="Your Name">
                    </div>
                    <div class="form-group">
                        <input type="tel" id="phone" name="phone" required placeholder="Phone Number">
                    </div>
                    <div class="form-group">
                        <input type="email" id="email" name="email" required placeholder="Email">
                    </div>
                    <div class="form-group">
                        <input type="text" id="country" name="country" required placeholder="Your Country">
                    </div>
                    <div class="form-group">
                        <input type="text" id="visa-country" name="visa_country" required
                            placeholder="Visa Required Country">
                    </div>
                    <div class="form-group">
                        <select id="visa-type" name="visa_type" required>
                            <option value="" disabled selected>Select Visa Type</option>
                            <option value="Tourist Visa">Tourist Visa</option>
                            <option value="Work Visa">Work Visa</option>
                            <option value="Student Visa">Student Visa</option>
                            <option value="Business Visa">Business Visa</option>
                        </select>
                    </div>
                    <button type="submit" class="submit-btn">Submit</button>
                </form>
            </div>
        </div>
      
    </section>

    <style>
        
/* Base Styles */
.hero {
    position: relative;
    padding-top: 120px;
    width: 100%;
    height: 110vh;
    background: url('/assets/herobg.jpg') no-repeat center center/cover;
    background-size: cover;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
    animation: background-zoom 10s ease-in-out infinite;
}

/* Glass Effect Overlay */
.hero-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(46, 46, 46, 0.22);
    border-radius: 16px;
    box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
    backdrop-filter: blur(10.4px);
    -webkit-backdrop-filter: blur(14.4px);
}

/* Hero Content Wrapper */
.hero-content-wrapper {
    position: absolute;
    display: flex;
    justify-content: space-between;
    align-items: center;
    width: 90%;
    max-width: 1600px;
    z-index: 1000;
}

/* Hero Content */
.hero-content {
    width: 50%;
    text-align: left;
    animation: slide-up 1s ease;
}

.hero-content h1 {
    font-size: 3.5rem;
    margin-bottom: 16px;
    font-weight: 900;
    color: #2a2a2a;
}

.hero-content p {
    font-size: 1.5rem;
    color: #111111;
    margin-bottom: 32px;
}

/* Registration Form */
.registration-form {
    position: relative;
    background: rgba(0, 0, 0, 0.7);
    backdrop-filter: blur(10.4px);
    -webkit-backdrop-filter: blur(14.4px);
    padding: 30px;
    border-radius: 16px;
    width: 35%;
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.5);
    animation: fade-in 1s ease;
}

.registration-form h2 {
    font-size: 24px;
    color: #ffcc00;
}

/* Form Group */
.form-group {
    margin-bottom: 16px;
}

.form-group input,
.form-group select {
    width: 100%;
    padding: 12px;
    border: none;
    border-radius: 8px;
    background-color: #1c1c1c;
    color: #fff;
    font-size: 16px;
    outline: none;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.form-group input:focus,
.form-group select:focus {
    transform: translateY(-3px) scale(1.05);
    box-shadow: 0 4px 12px rgba(255, 204, 0, 0.4);
}

/* Submit Button */
.submit-btn {
    width: 100%;
    padding: 14px;
    background-color: #ffcc00;
    color: #000;
    font-size: 18px;
    font-weight: 600;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: background-color 0.3s ease, transform 0.3s ease;
}

.submit-btn:hover {
    background-color: #e6a100;
    color: white;
    transform: translateY(-3px) scale(1.05);
}

/* Smooth Animation */
@keyframes background-zoom {
    0%, 100% {
        background-size: 100%;
    }
    50% {
        background-size: 110%;
    }
}

@keyframes fade-in {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes slide-up {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}
.plane-container {
    position: fixed;
    top: 50%; /* Starting point vertically */
    left: 0;
    z-index: 10;
}

.plane {
    width: 150px; /* Adjust size */
    height: auto;
    animation: plane-motion 10s ease-out infinite;
}

/* Projectile Motion Keyframes */
@keyframes plane-motion {
    0% {
        transform: translate(-80vw, 60vh) scale(0) rotate(0deg); /* Start from bottom left */
        opacity: 1;
    }
    
    /* 30% {
        transform: translate(50vw, 0vh) scale(1) rotate(-10deg); 
        opacity: 1;
    }   */
    100% {
        transform: translate(100vw, -50vh) scale(1.2) rotate(-5deg); /* End at top right */
        opacity: 1;
    }
}


/* CTA Buttons */
.cta-buttons {
    display: flex;
    gap: 20px;
}

.btn, .btn-secondary {
    padding: 14px 40px;
    font-size: 18px;
    font-weight: 600;
    border-radius: 30px;
    text-decoration: none;
    transition: background-color 0.3s ease, transform 0.3s ease;
    display: inline-block;
}

.btn {
    background-color: #ffcc00;
    color: #000;
    box-shadow: 0 4px 12px rgba(255, 204, 0, 0.4);
}

.btn:hover {
    background-color: #e6a100;
    color: white;
    transform: translateY(-3px) scale(1.05);
}

.btn-secondary {
    background-color: transparent;
    border: 2px solid #ffcc00;
    color: #ffcc00;
}

.btn-secondary:hover {
    background-color: #ffcc00;
    color: #000;
    transform: translateY(-3px) scale(1.05);
}

/* Background Animation */
@keyframes background-zoom {
    0% {
        transform: scale(1);
    }
    50% {
        transform: scale(1.05);
    }
    100% {
        transform: scale(1);
    }
}

/* Fade-In Animation */
@keyframes fade-in {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Slide-Up Animation */
@keyframes slide-up {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}
    </style><?php /**PATH C:\xampp\htdocs\laravel\StudyAbroad_Laravel\StudyAbroad_Laravel\resources\views/components/hero.blade.php ENDPATH**/ ?>