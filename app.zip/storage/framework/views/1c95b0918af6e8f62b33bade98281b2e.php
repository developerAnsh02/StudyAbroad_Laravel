<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>">
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('assets/image-removebg-preview (4).png')); ?>">

    <!-- Font Awesome CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <!-- JavaScript -->
    <script src="<?php echo e(asset('script.js')); ?>" defer></script>

    <title><?php echo $__env->yieldContent('title', 'Study Abroad'); ?></title>
</head>

<body>

    <!-- WhatsApp Floating Icon -->
    <div class="whatsapp-container">
        <a href="https://api.whatsapp.com/send?phone=YOUR_PHONE_NUMBER" target="_blank" class="whatsapp-icon">
            <img src="<?php echo e(asset('icons/WhatsApp_icon.png')); ?>" alt="WhatsApp" />
            <div class="tooltip">Chat with us on WhatsApp!</div>
        </a>
    </div>

    <?php echo $__env->make('layouts.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> <!-- Navigation Bar -->

    <main>
        <?php echo $__env->yieldContent('content'); ?> <!-- Page Content -->
    </main>

    <?php echo $__env->make('layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> <!-- Footer -->

    <button id="backToTop" class="back-to-top">↑</button>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            // Toggle Hamburger Menu
            function toggleMenu() {
                const overlay = document.querySelector('.hamburger-overlay');
                overlay.classList.toggle('active');

                document.body.style.overflow = overlay.classList.contains('active') ? 'hidden' : '';
            }

            // Navbar Scroll Effect
            document.addEventListener('scroll', () => {
                const navbar = document.querySelector('.navbar');
                if (window.scrollY > 50) {
                    navbar.classList.add('show'); // Slide down
                } else {
                    navbar.classList.remove('show'); // Slide up
                }
            });

            // Back to Top Button
            const backToTopButton = document.getElementById('backToTop');
            window.addEventListener('scroll', () => {
                backToTopButton.classList.toggle('show', window.scrollY > 300);
            });

            backToTopButton.addEventListener('click', () => {
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
        });
    </script>

</body>
</html>
<?php /**PATH /Users/amanmehta/Desktop/web_d/StudyAbroad_Laravel/resources/views/layouts/app.blade.php ENDPATH**/ ?>