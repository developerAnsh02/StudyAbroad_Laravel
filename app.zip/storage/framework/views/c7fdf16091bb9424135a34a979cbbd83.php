<footer class="footer">
        <div class="container">
            <!-- Left Section -->
            <div class="footer-left">
                <div class="logo">
                    <a href="#">StudyAbroad<span>.com</span></a>
                </div>
                <p>
                    Your trusted partner for securing visas to the USA, Canada, and Australia. We offer personalized
                    guidance, ensuring a smooth application process for tourist, student, and work visas.
                </p>
            </div>

            <!-- Middle Section -->
            <div class="footer-links">
                <div class="footer-column">
                    <h3>About</h3>
                    <ul>
                        <li><a href="#">About Us</a></li>
                        <li><a href="#">Consultant</a></li>
                        <li><a href="#">Contact Us</a></li>
                        <li><a href="#">Partners</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h3>Help</h3>
                    <ul>
                        <li><a href="#">Support</a></li>
                        <li><a href="#">FAQs</a></li>
                        <li><a href="#">Guides</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h3>Get In Touch</h3>
                    <ul>
                        <li><a href="#">Contact Us</a></li>
                        <li><a href="#">Request Callback</a></li>
                    </ul>
                </div>
            </div>

            <!-- Right Section -->
            <div class="footer-offices">
                <h3>Our Offices</h3>
                <div class="office-item">
                    <p><span>🇮🇳 Uttar Pradesh Office:</span> B Block, Sector 2, Noida, Uttar Pradesh 201301</p>
                </div>
                <div class="office-item">
                    <p><span>🇺🇸 New York Office:</span> 123 Street, New York, NY 10001</p>
                </div>
                <div class="office-item">
                    <p><span>🇬🇧 London Office:</span> 789 Street, London, UK W1A 1AA</p>
                </div>
            </div>
            
        </div>
        <div class="footer-social">
            <a href="#"><i class="fab fa-twitter"></i></a>
            <a href="#"><i class="fab fa-facebook"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
        </div>

        <div class="footer-bottom">
            <p>© 2025 StudyAbroad.com. Made with ❤ by Aman Mehta.</p>
            <p><a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a></p>
        </div>
    </footer><?php /**PATH /Users/amanmehta/Desktop/web_d/StudyAbroad_Laravel/resources/views/layouts/footer.blade.php ENDPATH**/ ?>